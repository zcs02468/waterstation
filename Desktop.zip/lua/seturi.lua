local request_method = ngx.var.request_method
local args = nil
local domain = nil
local secdomain = nil
local id = nil
local siteid = nil
if "GET" == request_method then
  args = ngx.req.get_uri_args()
elseif "POST" == request_method then
  ngx.req.read_body()
  args = ngx.req.get_post_args()
end
siteid = args["siteid"]
id = args["siteid"] .. "/" .. args["id"]
domain = args["fDomainName"]
secdomain = args["fSecDomainName"]


if id then
  local domainstr = string.gsub(domain, "%.", "_")
  domainstr = string.gsub(domainstr, "%-", "_")
  ngx.shared.lst:set(domainstr, id)
  local secdomainstr = string.gsub(secdomain, "%.", "_")
  secdomainstr = string.gsub(secdomainstr, "%-", "_")
  ngx.shared.lst:set(secdomainstr, id)
  local ww = "www_" .. domainstr
  ngx.shared.lst:set(ww, id)
  local www = string.gsub(secdomainstr, "_dev_zuma_com", "_m_dev_zuma_com")
  ngx.shared.lst:set(www, id)
  ngx.say(":)")
else
  ngx.say(":(")
end
