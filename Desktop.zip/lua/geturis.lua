function split(str, split_char)      
    local sub_str_tab = {}
    while true do          
        local pos = string.find(str, split_char) 
        if not pos then              
            table.insert(sub_str_tab,str)
            break
        end  
        local sub_str = string.sub(str, 1, pos - 1)              
        table.insert(sub_str_tab,sub_str)
        str = string.sub(str, pos + 1, string.len(str))
    end      
    return sub_str_tab
end

function getList(api)
    local res, err = httpc:request_uri(api)
    if res.status == ngx.HTTP_OK then
        local jsonstr = string.gsub(res.body, "%.", "_")
        jsonstr = string.gsub(jsonstr, "-", "_")
        jsonstr = string.gsub(jsonstr, "zumasite", "zuma")
        local ii = string.find(jsonstr, "%[")
        local j = string.find(jsonstr, "%]")
        jsonstr = string.sub(jsonstr, ii+1, j-1)
        jsonstr = string.gsub(jsonstr, "%},%{","}`{")
        local listdata = split(jsonstr, "`")
        for i, v in pairs(listdata) do
	    local dd = cjson.decode(listdata[i])
        local kk = dd["name"]
        local vv = dd["id"]
	    local p = string.find(kk, "_dev_zuma_com")
	    ngx.shared.lst:set(kk, vv)
        if p ~= nil then
            local ss = string.gsub(kk, "_dev_zuma_com", "_m_dev_zuma_com")
            ngx.shared.lst:set(ss, vv)
        else
            local ww = "www_" .. kk
            ngx.shared.lst:set(ww, vv)
        end
    else
        ngx.exit(res.status)
    end
end

local ok, err = ngx.timer.at(0, geturis)
if not ok then
    ngx.log(ngx.ERR, "failed to create the timer: ", err)
    return
end


local cjson = require("cjson")
local geturis
geturis = function(premateure)
    if premateure then
        return
    end

    local http = require("resty.http")
    local httpc = http.new()
    getList("http://manage.dev-zuma.com/manage-api/micro/site/queryDomainAndHomePageId")
    getList("http://manage.dev-zuma.com/manage-api/website/site/queryDominAndPageId")
end
