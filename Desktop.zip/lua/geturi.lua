if ngx.var.istemplate == "no" then
  local headers = ngx.req.get_headers() 
  local hoststr = headers["Host"]
  local domainstr = string.gsub(hoststr, "%.", "_")

  domainstr = string.gsub(domainstr, "%-", "_")
  domainstr = string.gsub(domainstr, "zumasite", "zuma")
  local siteid = nil
  local pageid = nil
  local separate = nil
  function getList(api)
    hoststr = string.gsub(hoststr, "www%.", "")
    local http = require("resty.http")
    local httpc = http.new()
    
    local res, err = httpc:request_uri(api)
    if res.status == ngx.HTTP_OK then
      local cjson = require("cjson")  
      local jsonstr = res.body
      local listdata = cjson.decode(jsonstr)
      local kk = domainstr
      local vv = listdata.data
      
      local p = string.find(kk, "_dev_zuma_com")
      separate =  string.find(tostring(vv), "/")
      ngx.shared.lst:set(kk, vv)
      if separate ~= nil then
        if p ~= nil then
            local ss = string.gsub(kk, "_dev_zuma_com", "_m_dev_zuma_com")
            ngx.shared.lst:set(ss, vv)
        else
            local ww = "www_" .. kk
            ngx.shared.lst:set(ww, vv)
        end
      end 
    else
        ngx.exit(res.status)
    end
  end

  if ngx.shared.lst:get(domainstr) == nil then
    getList("http://manage.dev-zuma.com/manage-api/website/site/queryDominAndPageId?fDominName=" .. hoststr)
    if siteid == nil then
      getList("http://manage.dev-zuma.com/manage-api/micro/site/queryDomainAndHomePageId?fDomainName=" .. hoststr)
    end
  end
  local newuri = ngx.shared.lst:get(domainstr)
  separate = string.find(newuri,"/")
  local siteid = string.sub(newuri,1,separate-1)
  local pageid = string.sub(newuri,separate+1)

  local siteidlen =  string.len(siteid)
  local sitefirst = string.sub(siteid,1,1)
  if ngx.var.uri == "" or ngx.var.uri == "/" then
    if siteidlen == 6 and sitefirst == "1" then
      ngx.var.proxy_pass_url = "http://192.168.0.201:8088/mpage/" .. pageid
    else
      if ngx.var.mobile_rewrite == "perform" then
        ngx.var.proxy_pass_url = "http://192.168.0.201:8081/tab/" .. pageid
      else
        ngx.var.proxy_pass_url = "http://192.168.0.201:8080/tab/" .. pageid
      end
    end
  else
    if siteidlen == 6 and sitefirst == "1" then
      ngx.var.proxy_pass_url = "http://192.168.0.201:8088"
    else
      if ngx.var.mobile_rewrite == "perform" then
        ngx.var.proxy_pass_url = "http://192.168.0.201:8081"
      else
        ngx.var.proxy_pass_url = "http://192.168.0.201:8080"
      end
    end
  end
elseif ngx.var.istemplate == "pc" then
  ngx.var.proxy_pass_url = "http://192.168.0.201:8080"
elseif ngx.var.istemplate == "mob" then
  ngx.var.proxy_pass_url = "http://192.168.0.201:8081"
elseif ngx.var.istemplate == "micro" then
  ngx.var.proxy_pass_url = "http://192.168.0.201:8088"
end

